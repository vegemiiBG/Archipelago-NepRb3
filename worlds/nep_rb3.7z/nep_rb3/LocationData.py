location_base_id = location_base_id = 7489397493

class LocationData:
    def __init__(self, name, id_, itemType):
        self.name = name
        self.itemType = itemType
        self.id = id_
