# Hyperdimension Neptunia Re;birth 3 V Generation

## What does randomization do to this game?

Players will begin in prologue at new game in an Open Mode state, with access to both the Hyper and Ultra dimensions from the start.
Dungeons and events will be randomized into the pool, offering either a linear run, or something that requires grinding materials for dungeons
or quests for checks. Even gather and treasure points inside of dungeons. Or large Medal turn ins.

## What is the goal of HDN RB3?

The goal is to obtain 5 Important Key Items in order to trigger the flag to fight the True End version of Rei Ryghts.

## What items and locations can get shuffled?

- All items, weapons, armors, ornaments, clothing and plans
- All Treasure and Gather points
- Quests, Colosseum rewards, enemy and boss drops
- All Dungeons, events, nations

## What does AP items for other worlds look like?

Currently not a feature.
