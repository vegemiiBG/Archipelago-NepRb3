"""Web UI related classes for Nep Rb3"""
from worlds.AutoWorld import WebWorld

class Rb3Web(WebWorld):
    """Web integration for Nep Rb3"""