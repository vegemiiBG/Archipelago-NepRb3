#Gather Point 1 - Change Dungeon
virtua_forest_safe_zone_changedungeon_gather1_reward1 = "Virtua Forest Safe Zone - Gather 1 (Change Dungeon) - Dogoo Jelly 1"
virtua_forest_safe_zone_changedungeon_gather1_reward2 = "Virtua Forest Safe Zone - Gather 1 (Change Dungeon) - Dogoo Jelly 2"

#Gather Point 2 - Change Dungeon
virtua_forest_safe_zone_changedungeon_gather2_reward1 = "Virtua Forest Safe Zone - Gather 2 (Change Dungeon) - Lizard Scale 1"
virtua_forest_safe_zone_changedungeon_gather2_reward2 = "Virtua Forest Safe Zone - Gather 2 (Change Dungeon) - Lizard Scale 2"

#Gather Point 3 - Change Dungeon
virtua_forest_safe_zone_changedungeon_gather3_reward1 = "Virtua Forest Safe Zone - Gather 3 (Change Dungeon) - Yellow Petal 1"
virtua_forest_safe_zone_changedungeon_gather3_reward1 = "Virtua Forest Safe Zone - Gather 3 (Change Dungeon) - Yellow Petal 2"

#Gather Point 4 - Change Dungeon
virtua_forest_safe_zone_changedungeon_gather4_reward1 = "Virtua Forest Safe Zone - Gather 4 (Change Dungeon) - Coin Fragment 1"
virtua_forest_safe_zone_changedungeon_gather4_reward2 = "Virtua Forest Safe Zone - Gather 4 (Change Dungeon) - Coin Fragment 2"
virtua_forest_safe_zone_changedungeon_gather4_reward3 = "Virtua Forest Safe Zone - Gather 4 (Change Dungeon) - Dogoo Jelly 1"
virtua_forest_safe_zone_changedungeon_gather4_reward4 = "Virtua Forest Safe Zone - Gather 4 (Change Dungeon) - Dogoo Jelly 2"

#Gather Point 5 - Change Dungeon
virtua_forest_safe_zone_changedungeon_gather5_reward1 = "Virtua Forest Safe Zone - Gather 5 (Change Dungeon) - Herb 1"
virtua_forest_safe_zone_changedungeon_gather5_reward2 = "Virtua Forest Safe Zone - Gather 5 (Change Dungeon) - Herb 2"
virtua_forest_safe_zone_changedungeon_gather5_reward3 = "Virtua Forest Safe Zone - Gather 5 (Change Dungeon) - Lizard Scale 1"
virtua_forest_safe_zone_changedungeon_gather5_reward4 = "Virtua Forest Safe Zone - Gather 5 (Change Dungeon) - Lizard Scale 2"

#Gather Point 6 - Change Dungeon
virtua_forest_safe_zone_changedungeon_gather6_reward1 = "Virtua Forest Safe Zone - Gather 6 (Change Dungeon) - Herb 1"
virtua_forest_safe_zone_changedungeon_gather6_reward2 = "Virtua Forest Safe Zone - Gather 6 (Change Dungeon) - Herb 2"
virtua_forest_safe_zone_changedungeon_gather6_reward3 = "Virtua Forest Safe Zone - Gather 6 (Change Dungeon) - Yellow Petal 1"
virtua_forest_safe_zone_changedungeon_gather6_reward4 = "Virtua Forest Safe Zone - Gather 6 (Change Dungeon) - Yellow Petal 2"

#Gather Point 7 - Change Dungeon
virtua_forest_safe_zone_changedungeon_gather7_reward1 = "Virtua Forest Safe Zone - Gather 7 (Change Dungeon) - Sunflowery Seed 1"
virtua_forest_safe_zone_changedungeon_gather7_reward2 = "Virtua Forest Safe Zone - Gather 7 (Change Dungeon) - Sunflowery Seed 2"
virtua_forest_safe_zone_changedungeon_gather7_reward3 = "Virtua Forest Safe Zone - Gather 7 (Change Dungeon) - Coin Fragment 1"
virtua_forest_safe_zone_changedungeon_gather7_reward4 = "Virtua Forest Safe Zone - Gather 7 (Change Dungeon) - Coin Fragment 2"
