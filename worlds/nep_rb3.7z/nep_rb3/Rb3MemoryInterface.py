import asyncio
import struct
from typing import List, Tuple
from pymem import pymem
from CommonClient import logger

class Rb3MemoryInterface():
    """Rb3MemoryInterface allows for reading and writing to the Rb3 game memory."""

    def __init__(self):
        self.rb3_memory = None
        self.rb3_processID = None

    def is_connected(self):
        if self.rb3_memory is None:
            return False
        
        return True
    
    def _read_byte(self, offset):
        """
        Read 1 byte of data at <base_process_address> + offset and return it.

        :int offset: the offset to read data from.
        """
        data = self.rb3_memory.read_bytes(self.rb3_memory.base_address + offset, 1)
        return data
    
    async def connect(self, exit_event: asyncio.Event):

        while not exit_event.is_set():
            try:
                self.rb3_memory = pymem.Pymem("NeptuniaReBirth3.exe")
                self.rb3_processID = self.rb3_memory.process_id
                return
                        
            except pymem.exception.ProcessNotFound:
                await asyncio.sleep(3)
    
